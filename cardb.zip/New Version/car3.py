# Created by Nicholas Pinero and Chris Laferriere
# This script uploads json data from a file and creates and populates an SQLite database with the data.
#
import json
import sqlite3

conn = sqlite3.connect('car2db.sqlite')
cur = conn.cursor()

# Execute a script , use triple quotes to include spaces and all.
#drop if exists is necessary to run the code more than one time.
cur.executescript('''

DROP TABLE IF EXISTS Model;
DROP TABLE IF EXISTS CarYear;
DROP TABLE IF EXISTS MODyear;
DROP TABLE IF EXISTS Manufacturer;

CREATE TABLE Model (
    make_id   TEXT UNIQUE,
    make_display   TEXT,
    make_is_common   INTEGER,
    make_country   TEXT,
    model_make_id  TEXT,
    PRIMARY KEY (make_id),
        FOREIGN KEY(model_make_id) REFERENCES Manufacturer(model_make_id)
);

CREATE TABLE CarYear (
    yid     INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT UNIQUE,
    yearM    INTEGER
);
CREATE TABLE Manufacturer (
    model_name  TEXT UNIQUE,
    model_make_id  TEXT,
    PRIMARY KEY (model_name, model_make_id)
);
CREATE TABLE MODyear(
    yid INTEGER,
    makeid TEXT Unique,
    PRIMARY KEY (yid, makeid),
        FOREIGN KEY(makeid) REFERENCES Model(make_id),
        FOREIGN KEY(yid) REFERENCES CarYear(yid)
);
''')
#Create two variables to keep the while statements going.
#the first while will allow us to insert any and all data we have until we
#have no more to insert. The second while statement will allow us to inset
#as many year/decade files as we have
#moreY stands for more years, set to yes to start so the while loop executes
moreY="yes"
#yesno refers to whether or not the user has data to enter.
yesno = raw_input('Is there data you would like to add? ')
while(yesno != "yes" or yesno!="Yes" or yesno!="no" or yesno!="No"):
    print("I'm sorry I didn't catch that. Plese enter yes or no")
    yesno = raw_input('Is there data you would like to add? ')
while(yesno == "yes" or yesno == "Yes"):
    
    while(moreY == "yes" or moreY =="Yes"):
        #Create two list variables to keep track of the yid and the make_id in
        #the year files since the make_id's are different than those found in the
        #model file
        yval = []
        mID =[]
        yname = ""
        #get the year the cars were being sold, store it to be used later
        fname = raw_input('What is the year? ')
        #since the year is the name of the file, adding .json will give us
        #the information needed to access the json file
        yname = fname+".json"

        if ( len(yname) < 1 ) : break

        # open the file and read 
        str_data = open(yname).read()
        # load the data in a 
        json_data = json.loads(str_data)

        for entry in json_data:
            #append the make_id to our list variable mID
            mID.append(str.lower(str(entry['make_id'])))
            #set the year to the int value for fname obtained earlier
            y = int(fname);
            #insert the year into the CarYear table
            cur.execute('''INSERT OR IGNORE INTO CarYear(yearM)  
                VALUES (?)''', (y, ) )
            #since yid is autoincrement, we do not need to insert a value for
            #it but we need to get that value to put it into our combined table
            #between year and model.
            cur.execute('SELECT MAX(yid) FROM CarYear LIMIT 1 ')
            thing = cur.fetchone()[0]
            yval.append(int(thing))

            conn.commit()
        #if there are more year files say yes otherwise no will get us out of
        #the loop
        moreY = raw_input('Is there another year you would like to add? ')

            
    #prompt user for the manufacturers file and store it in yname
    yname = raw_input('Enter Manufacturer file name: ')
    if ( len(yname) < 1 ) : break

    # open the file and read 
    str_data = open(yname).read()
    # load the data in a 
    json_data = json.loads(str_data)

    #Create an array to store the different model_make_id's so we caninsert them
    #as a foreign key later
    modelMan = ["hi"]
    for ent in json_data:
        #get the model name and model make id, convert them to strings
        #and store them in their respective variables to add them to the table.
        modelN = str(ent['model_name'])
        modelMI = str(ent['model_make_id'])

        #add model name and model make id to the Manufacturer table
        cur.execute('''INSERT OR IGNORE INTO Manufacturer(model_name,model_make_id)  
            VALUES ( ?,?)''', ( modelN,modelMI) )
        #find length of the modelMan list and set i to that length, this will
        #help us check to see if we need to add a new model make id to the list.
        #By doing this, we won't have repeated model make id's in our modelMan
        #list
        i=len(modelMan)
        if(modelMan[i-1] != str.lower(modelMI)):
            if(modelMan[0] == "hi"):
                modelMan[0] = modelMI
            else:
                modelMan.append(modelMI)
        conn.commit()

    #ask for the model file name
    yname = raw_input('Enter Model file name: ')
    if ( len(yname) < 1 ) : break

    # open the file and read 
    str_data = open(yname).read()
    # load the data in a 
    json_data = json.loads(str_data)

    i=0
    x=0
    for ent in json_data:
        #set the model's make id, display, is common, and country to their
        #respective variables to make it easier.
        modI = ent['make_id']
        makeD = ent['make_display']
        makeIC = ent['make_is_common']
        makeC = ent['make_country']

        #Check to see if the foreign key from Manufacturer, model_make_id
        #has to be added to this tuple by seeing if the id is the same as the
        #make id or make display of the model. This is possible since our data
        #is in alphabetical order.
        if(modelMan[i] ==modI or modelMan[i] ==makeD):
            #if the condition is met, add the model make id to that tuple
            cur.execute('''INSERT OR IGNORE INTO Model(make_id, make_display, make_is_common, make_country, model_make_id)  
                VALUES ( ?,?,?,?,?)''', ( modI, makeD, makeIC, makeC,modelMan[i]) )
            #to prevent an index out of bounds error, only increment i if the
            #i is less than the length of modelMan -1
            if(i!= len(modelMan)-1):i =i+1
        else:
            #if the condition is not met, then insert all other data
            #into the tuple
            cur.execute('''INSERT OR IGNORE INTO Model(make_id, make_display, make_is_common, make_country)  
                VALUES ( ?,?,?,?)''', ( modI, makeD, makeIC, makeC) )

        #if the make id found in the year files matches that of the model's
        #make id, then add the year id value to the tuple
        if(mID[x] == modI ):
            cur.execute('''INSERT OR IGNORE INTO MODyear(yid,makeid)  
                VALUES (?, ?)''', (yval[x], modI,) )
            #if x is equal to the length of mID -1 then stop incrementing x to
            #prevent index out of bounds error
            if(x!= len(mID)-1):x=x+1
            
        else:
            #if the make id found in the year files doesn't match that of
            #the make id in the model file, then don't add the year id
            cur.execute('''INSERT OR IGNORE INTO MODyear(makeid)  
                VALUES (?)''', (modI,))
        conn.commit()
    #if we had more data to enter into our table, we would answer yes,
    #otherwise we answer no to exit the while loop and end the script.
    yesno = raw_input('Is there data you would like to add? ')
    while(yesno != "yes" or yesno!="Yes" or yesno!="no" or yesno!="No"):
        print("I'm sorry I didn't catch that. Plese enter yes or no")
        yesno = raw_input('Is there data you would like to add? ')
    if(yesno == "no" or yesno =="No"):
        conn.close()



